#!/usr/bin/env sh

echo "Zip-Slip exploited!"
